flag = 0
kon = []

for A in range(0, 10000):
    flag = 0
    for x in range(0, 10000):
        if (((x % 3) == 0) <= (not((x % 5) == 0))) or ((x + A) >= 90):
            flag += 1


    if flag >= 10000:
        kon.append(A)


print(min(kon))